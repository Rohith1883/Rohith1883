package com.app.enums;

//public enum Role {
//	ADMIN, USER, GUEST
//	// Add other roles as needed
//}
