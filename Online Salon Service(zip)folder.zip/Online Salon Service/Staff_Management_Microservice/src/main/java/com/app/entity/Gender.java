package com.app.entity;

public enum Gender {
	MALE, FEMALE, OTHER
}
